<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Diary</a></li>
</ol>

<h2>DIARY
<a type="button" class="btn btn-success btn-simple pull-right" style="float:right; margin-top:-5px" data-toggle="collapse" data-target="#tambahdiary"><i class="fa fa-plus-square" style="margin-right:10px" ></i>Tambah</a>
</h2>
<div class="x_title">
</div>

<div id="tambahdiary" class="collapse" style="margin-left:0px; margin-right:0px; margin-top:0px">
  <script type="text/javascript" src="<?php echo e(asset('/js/tinymce/tinymce.min.js')); ?>"></script>
  <script type="text/javascript">
  tinymce.init({
    selector : "textarea",
    plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste jbimages"],
    toolbar : "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image jbimages",
  });
  </script>

  <form action="<?php echo e(url('diarynewpost')); ?>" method="post">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="form-group">
      <input required="required" value="<?php echo e(old('title')); ?>" placeholder="Enter title here" type="text" name = "title"class="form-control" />
    </div>
    <div class="form-group">
      <textarea name='body'class="form-control"><?php echo e(old('body')); ?></textarea>
    </div>
    <input type="submit" name='publish' class="btn btn-success pull-right" value = "Publish"/>
    <input type="submit" name='save' class="btn btn-default pull-right" value = "Save Draft" />
  </form>
  <hr>
</div>



<?php if(Session::has('flash_message_tambah')): ?>
    <div class="alert alert-success"><strong>Sukses!</strong> Anda berhasil menambah diary.<em> <?php echo session('flash_message'); ?></em></div>
<?php endif; ?>
<?php if(Session::has('flash_message_hapus')): ?>
    <div class="alert alert-danger"><strong>Sukses!</strong> Anda berhasil menghapus diary.<em> <?php echo session('flash_message'); ?></em></div>
<?php endif; ?>
<?php if(Session::has('flash_message_edit')): ?>
    <div class="alert alert-warning"><strong>Sukses!</strong> Anda berhasil mengubah diary.<em> <?php echo session('flash_message'); ?></em></div>
<?php endif; ?>
<script type="text/javascript">
$('div.alert').delay(5000).slideUp(300);
</script>

<!-- <a href="<?php echo url('diarynewpost'); ?>"><button type="button" class="btn btn-default">Buat Diary</button></a> -->

    <?php foreach( $diarys as $diary ): ?>
    <div class="list-group" style="margin-top:5px">
        <div class="list-group-item">
            <h3><a href="<?php echo e(url('/'.$diary->slug)); ?>"><?php echo e($diary->title); ?></a>


                    <?php if (Auth::check() && Auth::user()->is(1)): ?>
                    <?php if($diary->active == '1'): ?>
                    <div class="btn-group pull-right" role="group" >
                      <button type="button" class="btn btn-warning btn-simple" data-toggle="collapse" data-target="#editdiary<?php echo $diary->id;?>"> <i class=" fa fa-pencil-square-o"></i></button>
                      <button type="button" class="btn btn-danger btn-simple" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $diary->id;?>"><span class="fa fa-trash"></button>
                    </div>

                    <div class="modal fade" id="modaldelete<?php echo $diary->id;?>" tabindex="-1" role="dialog" >
                      <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                                  <h4 class="modal-title"><b>Perhatian</b></h4>
                              </div>

                              <div class="modal-body">
                                  <input type="hidden" value="<?php echo $diary->id;?>" name="id">
                                  <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                              </div>
                              <div class="modal-footer">
                                  <a type="button" class="btn btn-info btn-simple pull-left" data-dismiss="modal" style="width:60px;">Tidak</a>
                                  <a class="btn btn-danger btn-simple pull-right" title="Hapus" href="<?php echo e(url('/diarydelete/'.$diary->id.'?_token='.csrf_token())); ?>"style="width:60px;">Ya</a>
                              </div>
                            </div>
                          </div>
                      </div>

                    <div id="editdiary<?php echo $diary->id;?>" class="collapse" style="margin-left:10px; margin-right:10px; margin-top:50px;">

                      <script type="text/javascript" src="<?php echo e(asset('/js/tinymce/tinymce.min.js')); ?>"></script>
                      <script type="text/javascript">
                      tinymce.init({
                        selector : "textarea",
                        plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste jbimages"],
                        toolbar : "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image jbimages"
                      });
                      </script>

                      <form action="<?php echo e(action('DiaryController@update')); ?>" method="post" enctype="multipart/form-data">
                             <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                             <input type="hidden" name="diary_id" value="<?php echo e($diary->id); ?><?php echo e(old('diary_id')); ?>">
                             <div class="form-group">
                               <input required="required" value="<?php if(!old('title')): ?><?php echo e($diary->title); ?><?php endif; ?><?php echo e(old('title')); ?>" placeholder="Judul" type="text" name = "title"class="form-control" />
                             </div>
                             <div class="form-group">
                               <textarea name='body'class="form-control">
                                 <?php if(!old('body')): ?>
                                 <?php echo $diary->body; ?>

                                 <?php endif; ?>
                                 <?php echo old('body'); ?>

                               </textarea>
                             </div>

                             <?php if($diary->active == '1'): ?>
                             <input type="submit" name='publish' class="btn btn-success" value = "Update" style="float:right; margin-left:10px" />
                             <?php else: ?>
                             <input type="submit" name='publish' class="btn btn-success" value = "Publish" style="float:right; margin-left:10px"/>
                             <?php endif; ?>
                             <?php if (Auth::check() && Auth::user()->is(1)): ?>
                             <a type="button" href="<?php echo e(url('/diarydelete/'.$diary->id.'?_token='.csrf_token())); ?>" class="btn btn-danger" style="float:right">Delete</a>
                             <?php endif; ?>
                            </form>
                    <?php endif; ?>
                    <?php endif; ?>
            </h3>
            <h5><?php echo e($diary->created_at->format('M d,Y \a\t h:i a')); ?> by <?php echo e($diary->author->name); ?></h5>

            <div class="text" style="width:100%; overflow:auto"  >
              <?php echo $diary->body ?>
              <!-- <article>
              <?php echo str_limit($diary->body, $limit = 100, $end = '....... <a href='.url("/diary/".$diary->slug).'>Read More</a>'); ?>

            </article> -->
          </div>
        </div>
    </div>
    <?php endforeach; ?>
    <?php echo $diarys->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>