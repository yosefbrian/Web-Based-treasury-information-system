<?php $__env->startSection('content'); ?>

<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Lihat Profil</a></li>
</ol>

<?php foreach($profil as $profile): ?>
 <h2>LIHAT PROFIL
   <a href="<?php echo url('editprofil/'.$profile->id); ?>" type="button" class="btn btn-warning btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-pencil" style="margin-right:10px"></i>Edit Profil</a>
</h2>

 <div class="x_title">
 </div>

 <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" style="margin-top:20px">
 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Nama </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="nama" value="<?php echo e($profile->nama); ?>" class="form-control col-md-7 col-xs-12" disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">NIP </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="nip" value="<?php echo e($profile->nip); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Jabatan</label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="jabatan" value="<?php echo e($profile->jabatan); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">NPWP
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="npwp" value="<?php echo e($profile->npwp); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Jenis Kelamin
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="jenis_kelamin" value="<?php echo e($profile->jenis_kelamin); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Nm Status Pegawai
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="nm_status_pegawai" value="<?php echo e($profile->nm_status_pegawai); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Pangkat
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="pangkat" value="<?php echo e($profile->pangkat); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Jenis Jabatan
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="jenis_jabatan" value=" <?php echo e($profile->jenis_kelamin); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Unit Organisasi
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="unit_organisasi" value="<?php echo e($profile->unit_organisasi); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Jabatan Grade
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="jabatan_grade" value="<?php echo e($profile->jabatan_grade); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Nama Bank
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="nama_bank" value="<?php echo e($profile->nama_bank); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">No Rekening
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="no_rekening" value="<?php echo e($profile->no_rekening); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Nama Rekening
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <input type="text" name="nama_rekening" value="<?php echo e($profile->nama_rekening); ?>" class="form-control col-md-7 col-xs-12"disabled="disabled">
     </div>
   </div>

<?php if($profile->filename != ''): ?>
   <div class="form-group">
     <label class="control-label col-md-3 col-sm-3 col-xs-12">Scan Rekening
     </label>
     <div class="col-md-6 col-sm-6 col-xs-12">
       <a href="/upload/rekening/<?php echo $profile->filename;?>"> Scan Rekening</a>
     </div>
   </div>


   <?php endif; ?>
   <?php endforeach; ?>

 </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>