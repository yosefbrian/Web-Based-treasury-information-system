<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Reimbursement</a></li>
  <li><a href="#">List SPD Cari</a></li>
</ol>

<style type="text/css">

    table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
</style>

<h2>LIST SPD Cari</h2>
<div class="x_title">
</div>

<?php if (Auth::check() && Auth::user()->is(1)): ?>
<a href="<?php echo e(url('admin/listspd')); ?>"><button>kembali</button></a>
<?php endif; ?>


<?php if (Auth::check() && Auth::user()->is(3)): ?>
<a href="<?php echo e(url('spd/listspd')); ?>"><button>kembali</button></a>
<?php endif; ?>

<table>

  <tr>
    <th>No PD</th>
    <th>No ST</th>
    <th>NIP</th>
    <th>Nama Lengkap</th>
   <!--  <th>Berangkat</th>
    <th>Tujuan</th>
    <th>Tanggal</th>
    <th>Kegiatan</th>
    <th>Keterangan</th>
    <th>Nama PPK</th>
 -->
   </tr>

   <?php $i=0; ?>
                <?php foreach($result as $espede): ?>
                    <?php $i++; ?>
  <tr>
    <td><?php echo e($espede->no_pd); ?></td>
     <td><?php echo e($espede->no_st); ?></td>
     <td><?php echo e($espede->nip); ?></td>
     <td><?php echo e($espede->nama); ?></td>
     <td> <a class="btn btn-primary" data-placement="bottom" title="Lihat Data" data-toggle="modal" data-id ="espede->id" data-target="#modalshow<?php echo $espede->id;?>" href="#"><span class="glyphicon glyphicon-user"></span></a></td>

     <div class="modal fade" id="modalshow<?php echo $espede->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title"><b>Detil SPD</b></h4>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $espede->id;?>" name="id">
                                    <div class="panel panel-group">
                                        <div class="panel-body">
                                            <div class="row col-md-10 col-md-offset-1">
                                                <div class="row">
                                                    <div class="form-group">
                                                        <label class="col-sm-6"><div class="pull-right">&nbsp;</div></label>
                                                        <div class="col-sm-6"></div>
                                                    </div>
                                                </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Pengiriman
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->pengiriman); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Nomor PD:
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->no_pd); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Nomor ST :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->no_st); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    NIP :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->nip); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Nama :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->nama); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Berangkat :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->berangkat); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Tujuan :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->tujuan); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Tanggal :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->tanggal); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Kegiatan :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->keterangan); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="col-sm-6">
                                                                <div class="pull-right">
                                                                    Nama PPK :
                                                                </div>
                                                            </label>
                                                            <div class="col-sm-6"><?php echo e($espede->nama_ppk); ?></div>
                                                        </div>
                                                    </div>


                                                    </div>
                                                </div>
                                        </div>
                                    </div>
                                </div>


                                    <button type="button" title="Kembali" class="btn btn-default btn-simple" data-dismiss="modal">Kembali</button>
                                    <div class="divider"></div>
                                    <a class="btn btn-warning btn-simple" title="Hapus" href="#">Ganti</a>

                            </div>
                           </div>

                           <?php if (Auth::check() && Auth::user()->is(1)): ?>
                           <td><a class="btn btn-warning" data-placement="bottom" title="Edit Data" href="<?php echo e(url('admin/listspd/'.$espede->id.'/ubah')); ?>"><span class="glyphicon glyphicon-pencil"></a></td>
                           <?php endif; ?>

                           <?php if (Auth::check() && Auth::user()->is(3)): ?>
                           <td><a class="btn btn-warning" data-placement="bottom" title="Edit Data" href="<?php echo e(url('spd/listspd/'.$espede->id.'/ubah')); ?>"><span class="glyphicon glyphicon-pencil"></a></td>
                           <?php endif; ?>


                    		<td><a class="btn btn-danger" data-placement="bottom" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $espede->id;?>"><span class="glyphicon glyphicon-trash"></a></td>

                             <div class="modal fade" id="modaldelete<?php echo $espede->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title"><b>Perhatian</b></h4>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $espede->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Kembali</button>
                                    <div class="divider"></div>
                                    <a class="btn btn-danger btn-simple" title="Hapus" href="<?php echo e(action('SPDController@delete', $espede->id)); ?>">Hapus</a>
                                </div>
                            </div>
                        </div>
                    </div>

   <!--   <td><?php echo e($espede->berangkat); ?></td>
     <td><?php echo e($espede->tujuan); ?></td>
     <td><?php echo e($espede->tanggal); ?></td>
     <td><?php echo e($espede->kegiatan); ?></td>
     <td><?php echo e($espede->keterangan); ?></td>
     <td><?php echo e($espede->nama_ppk); ?></td> -->

  </tr>
 <?php endforeach; ?>

 </table>

<?php echo $result->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>