<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Daftar User</a></li>
</ol>
<style type="text/css">

    table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
</style>

<h2>DAFTAR USER

<?php if (Auth::check() && Auth::user()->is(1)): ?>
  <a href="<?php echo e(url('admin/registeri')); ?>" type="button" class="btn btn-success btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-plus-square" style="margin-right:10px"></i>Tambah User</a>
<?php endif; ?>

<?php if (Auth::check() && Auth::user()->is(3)): ?>
  <a href="<?php echo e(url('spd/registeri')); ?>" type="button" class="btn btn-success btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-plus-square" style="margin-right:10px"></i>Tambah User</a>
<?php endif; ?>


</h2>
<div class="x_title">
</div>


<!-- <div class="col-xs-12"><a href="<?php echo e(url('admin/registeri')); ?>" title="Tambah" class="btn btn-default btn-fill">Tambah Pegawai</a> -->
<!--   <div class="form-group" style="float:right"> -->
    
<?php if (Auth::check() && Auth::user()->is(1)): ?>
    <form action="<?php echo e(url('/admin/daftaruser/cari/')); ?>" method="post" enctype="multipart/form-data">
      <button type="submit" class="btn btn-default pull-right"><span class="fa fa-search"></span></button>
        <div class="col-sm-4 pull-right">
          <input class="form-control"  type="text" name="kata_kunci" placeholder="cari.." >
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"><br>
<!--    <button class="btn btn-round glyphicon glyphicon-search" type="submit"></button>-->
        </div>
    </form>
  </div>
  <?php endif; ?>

  <?php if (Auth::check() && Auth::user()->is(3)): ?>
    <form action="<?php echo e(url('/spd/daftaruser/cari/')); ?>" method="post" enctype="multipart/form-data">
      <button type="submit" class="btn btn-default pull-right"><span class="fa fa-search"></span></button>
        <div class="col-sm-4 pull-right">
          <input class="form-control"  type="text" name="kata_kunci" placeholder="cari.." >
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"><br>
<!--    <button class="btn btn-round glyphicon glyphicon-search" type="submit"></button>-->
        </div>
    </form>
  </div>
  <?php endif; ?>

<div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th class="text-center">Id</th>
                    <th class="text-center">NIP</th>
                    <th class="text-center">Nama</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
                <?php foreach($employeList as $book): ?>
                    <?php $i++; ?>
                <tr>
                    <td class="text-center"><?php echo e($book->id); ?></td>
                    <td ><?php echo e($book->email); ?></td>
                    <td ><?php echo e($book->name); ?></td>
                    <td class="text-center">

                    <?php if (Auth::check() && Auth::user()->is(1)): ?>
                      <a class="btn btn-warning" data-placement="bottom" title="Edit Data" href="<?php echo e(url('admin/editprofiluser/'.$book->id)); ?>"><span class="glyphicon glyphicon-pencil"></a>
                      <a class="btn btn-primary" data-placement="bottom" title="Ganti Password" href="<?php echo e(url('admin/gantipassworduser/'.$book->id)); ?>"><span class="fa fa-key"></a>
                      <a class="btn btn-danger" data-placement="bottom" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $book->id?>"><span class="glyphicon glyphicon-trash"></a>
                    <?php endif; ?>



                    <?php if (Auth::check() && Auth::user()->is(3)): ?>
                      <a class="btn btn-warning" data-placement="bottom" title="Edit Data" href="<?php echo e(url('spd/editprofiluser/'.$book->id)); ?>"><span class="glyphicon glyphicon-pencil"></a>
                      <a class="btn btn-primary" data-placement="bottom" title="Ganti Password" href="<?php echo e(url('spd/gantipassworduser/'.$book->id)); ?>"><span class="fa fa-key"></a>
                      <a class="btn btn-danger" data-placement="bottom" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $book->id?>"><span class="glyphicon glyphicon-trash"></a>
                    <?php endif; ?>



                    </td>



<?php if (Auth::check() && Auth::user()->is(3)): ?>
                    <div class="modal fade" id="modaldelete<?php echo $book->id?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title"><b>Perhatian</b></h4>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $book->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-info btn-simple pull-left" data-dismiss="modal" style="width:60px">Tidak</button>
                                    <a class="btn btn-danger btn-simple pull-right" title="Hapus" style="width:60px" href="<?php echo e(url('spd/daftaruser/employees/'.$book->id.'/delete')); ?>">Ya</a>
                                </div>
                            </div>
                        </div>
                    </div>
<?php endif; ?>



<?php if (Auth::check() && Auth::user()->is(1)): ?>
                    <div class="modal fade" id="modaldelete<?php echo $book->id?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title"><b>Perhatian</b></h4>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $book->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-info btn-simple pull-left" data-dismiss="modal" style="width:60px">Tidak</button>
                                    <a class="btn btn-danger btn-simple pull-right" title="Hapus" style="width:60px" href="<?php echo e(action('UserController@delete', $book->id)); ?>">Ya</a>
                                </div>
                            </div>
                        </div>
                    </div>
<?php endif; ?>

                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <center>
        <?php echo $employeList->render(); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>