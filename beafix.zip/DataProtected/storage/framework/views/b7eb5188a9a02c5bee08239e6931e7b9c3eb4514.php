<table>
  <tbody>
    <tr>
      <th>id</th>
      <th>spd_id</th>
  		<th>no_spd</th>
      <th>no_pp</th>
     	<th>no_spp</th>
      <th>tgl_spp</th>
      <th>tiket_berangkat</th>
      <th>tiket_kembali</th>
      <th>dpr</th>
      <th>penginapan</th>
      <th>penginapan_tanpa_bukti</th>
      <th>uh</th>
      <th>uhr</th>
      <th>kekurangan</th>
      <th>perjalanan_dinas</th>
      <th>angkutan_pegawai</th>
      <th>angkutan_keluarga</th>
      <th>angkutan_prt</th>
      <th>pengepakan</th>
      <th>angkutan_barang</th>
      <th>uang_harian_tiba</th>
      <th>uang_harian_bertolak</th>
      <th>uang_harian_pembantu</th>
      <th>total</th>
      <th>created_at</th>

  </tr>
  <?php foreach($users as $user): ?>
  <tr>
  	<td><?php echo e($user['id']); ?></td>
    <td><?php echo e($user['spd_id']); ?></td>
    <td><?php echo e($user['no_spd']); ?></td>
  	<td><?php echo e($user['no_pp']); ?></td>
    <td><?php echo e($user['no_spp']); ?></td>
    <td><?php echo e($user['tgl_spp']); ?></td>
    <td><?php echo e($user['tiket_berangkat']); ?></td>
    <td><?php echo e($user['tiket_kembali']); ?></td>
    <td><?php echo e($user['dpr']); ?></td>
    <td><?php echo e($user['penginapan']); ?></td>
    <td><?php echo e($user['penginapan_tanpa_bukti']); ?></td>
    <td><?php echo e($user['uh']); ?></td>
    <td><?php echo e($user['uhr']); ?></td>
    <td><?php echo e($user['kekurangan']); ?></td>
    <td><?php echo e($user['perjalanan_dinas']); ?></td>
    <td><?php echo e($user['angkutan_pegawai']); ?></td>
    <td><?php echo e($user['angkutan_keluarga']); ?></td>
    <td><?php echo e($user['angkutan_prt']); ?></td>
    <td><?php echo e($user['pengepakan']); ?></td>
    <td><?php echo e($user['angkutan_barang']); ?></td>
    <td><?php echo e($user['uang_harian_tiba']); ?></td>
    <td><?php echo e($user['uang_harian_bertolak']); ?></td>
    <td><?php echo e($user['uang_harian_pembantu']); ?></td>
    <td><?php echo e($user['total']); ?></td>
    <td><?php echo e(substr($user['created_at'],0,10)); ?></td>

  </tr>
  <?php endforeach; ?>
 </tbody>
</table>