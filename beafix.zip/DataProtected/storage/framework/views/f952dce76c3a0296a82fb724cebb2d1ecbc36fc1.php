<?php $__env->startSection('content'); ?>

<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Statistik</a></li>
  <li><a href="#">Pengeluaran</a></li>
</ol>


<div class="row">
    <div class="page-header">
        <h2>Pengeluaran per Tahun</h2>
    </div>
    <a href="<?php echo e(url('admin/statistik/pengeluaranbulan')); ?>">Pengeluaran per Bulan</a></li>
    <a href="<?php echo e(url('admin/statistik/transportasitahun')); ?>">Pengeluaran Transportasi</a></li>
    <a href="<?php echo e(url('admin/statistik/dprtahun')); ?>">Pengeluaran DPR</a></li>
    <a href="<?php echo e(url('admin/statistik/akomodasitahun')); ?>">Pengeluaran Akomodasi</a></li>
    <a href="<?php echo e(url('admin/statistik/uhtahun')); ?>">Pengeluaran Uang Harian</a></li>
    <a href="<?php echo e(url('admin/statistik/angkutantahun')); ?>">Pengeluaran Angkutan</a></li>
</div>
<div id="pengeluaran-div" align="center" style="width: 1000px; height: 700px"></div>

<?= \Lava::render('BarChart', 'Pengeluaran', 'pengeluaran-div') ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>