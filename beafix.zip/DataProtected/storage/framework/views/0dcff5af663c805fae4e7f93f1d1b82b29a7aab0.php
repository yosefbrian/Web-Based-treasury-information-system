<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
  <li><a href="#">Reimbursement</a></li>
  <li><a href="#">SPD Center Admin</a></li>
</ol>
<style type="text/css">

    table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
</style>

<h2>SPD CENTER ADMIN

<?php if (Auth::check() && Auth::user()->is(1)): ?>
  <a href="<?php echo e(url('admin/listspd')); ?>" type="button" class="btn btn-info btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-list-alt" style="margin-right:10px"></i>List SPD</a>
<?php endif; ?>

<?php if (Auth::check() && Auth::user()->is(3)): ?>
  <a href="<?php echo e(url('spd/listspd')); ?>" type="button" class="btn btn-info btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-list-alt" style="margin-right:10px"></i>List SPD</a>
<?php endif; ?>

<?php if (Auth::check() && Auth::user()->is(2)): ?>
  <a href="<?php echo e(url('bp/listspd')); ?>" type="button" class="btn btn-info btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-list-alt" style="margin-right:10px"></i>List SPD</a>
<?php endif; ?>


<?php if (Auth::check() && Auth::user()->is(5)): ?>
  <a href="<?php echo e(url('bp2/listspd')); ?>" type="button" class="btn btn-info btn-simple pull-right" style="float:right; margin-top:-5px"><i class="fa fa-list-alt" style="margin-right:10px"></i>List SPD</a>
<?php endif; ?>


</h2>
<div class="x_title">
</div>
<?php if (Auth::check() && Auth::user()->is(1)): ?>
<form action="<?php echo e(url('admin/spdsearch')); ?>" method="post">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
<div class="">
  <input class="btn btn-default pull-right" type="submit" value="Cari" ></input>
  <input class="form-control pull-right" type="text" name="spdsearch" id="spdsearch" placeholder="cari.." style="width: 200px; height:30px; margin-top: 2px;margin-right:10px"></input>
</div>
</form>
<?php endif; ?>



<?php if (Auth::check() && Auth::user()->is(3)): ?>
<form action="<?php echo e(url('spd/spdsearch')); ?>" method="post">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
<input type="text" name="spdsearch" id="spdsearch"></input>
<input class="btn btn-default" type="submit" value="Cari" >
</form>
<?php endif; ?>


<table>


  <tr>
    <th>NIP</th>
    <th>Nama Lengkap</th>
   <?php if (Auth::check() && Auth::user()->is(1)): ?>

    <th>Aksi</th>
   <?php endif; ?>

   <?php if (Auth::check() && Auth::user()->is(3)): ?>

    <th>Aksi</th>
   <?php endif; ?>

   </tr>

   <?php $i=0; ?>
                <?php foreach($profil as $profile): ?>
                    <?php $i++; ?>
  <tr>
    <td><?php echo e($profile->nip); ?></td>
     <td><?php echo e($profile->nama); ?></td>

     <?php if (Auth::check() && Auth::user()->is(1)): ?>
     <td><a href="<?php echo url('admin/spdcenter/'.$profile->id); ?>">Buat Data</a></td>
    <?php endif; ?>


     <?php if (Auth::check() && Auth::user()->is(3)): ?>
     <td><a href="<?php echo url('spd/spdcenter/'.$profile->id); ?>">Buat Data</a></td>
    <?php endif; ?>


    </tr>
 <?php endforeach; ?>

 </table>



<table>
</table>
<?php echo $profil->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>